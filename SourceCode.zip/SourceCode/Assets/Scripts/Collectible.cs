using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Rarity
{
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
}

public class Collectible : MonoBehaviour
{
    public string Name { get; set; }
    public Rarity Rarity { get; set; }

    public Collectible(string name, Rarity rarity)
    {
        Name = name;
        Rarity = rarity;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Collectible picked up!");
            Destroy(gameObject);
        }
    }
}

public class Cannister : MonoBehaviour
{
    void Start()
    {
        Collectible Cannister = new Collectible("Cannister", Rarity.Legendary);
        Debug.Log("Name: " + Cannister.Name);
        Debug.Log("Rarity: " + Cannister.Rarity);
    }
}